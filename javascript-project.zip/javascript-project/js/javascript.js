let bupper = "check uppercase text"
     bupper =bupper.toUpperCase();
     console.log(bupper)
    
      // variyables and data type start here
      // const age = 24;
      // let page = 10.88;
      // let number = -50;
      // let fullName = "bhupender singh";
      isFollow = true;
      // let x = null;
      // let x = BigInt("123");
      // let y = Symbol("Hello");

      // const student = {
      //     fullName: "bhupender singh",
      // age: 25,
      //     cgpa: 8.2,
      //     isPass: true
      // }
      // student["name"] = "dimpal"
      // console.log(student["name"])

      // variyables and data type end here

      // operator and conditional statement start here

      // arithmetic operators start here

      // let a = 5;
      // let b = 10;
      // console.log('a = ', a, "& b=", b);
      // console.log('a + b = ', a + b);
      // console.log('a - b = ', a - b);
      // console.log('a * b = ', a * b);
      // console.log('a / b = ', a / b);
      // console.log('a % b = ', a % b);

      // let a = 5;
      // let b = 10;
      // console.log('a = ', a, "& b=", b);
      // console.log('a-- =',a-- );
      // console.log("a=",a)

      // arithmetic operators end here

      // assignment operators start here

      // let a = 5;
      // let b = 10;
      // a += 4;
      // a -= 4;
      // a -= 4;
      // a *= 4;
      // a %= 4;
      // b **= 4;
      // console.log("b = ", b);

      // assignment operators end here

      // Comparison operators start here

      // let a = 6;
      // let b = 5;
      // console.log("5 !== 2", a !== b);
      // console.log("6 >= 5", a  >= b)

      // Comparison operators end here

      //  logical operatoe start here

      // let a = 6;
      // let b = 5;

      // let cond1 = a > b;
      // let cond2 = a === 7;

      // console.log("!(6<5) = ", !(a < b ));

      //  logical operatoe end here

      // condition statement start here

      // let stare = 18;

      // if(stare > 18){
      //     console.log("you can vote");
      // }
      // if(stare < 18){
      //     console.log("you cannot vote");
      // }

      // let mode =  "light"
      // let color;

      // if(mode === "dark"){
      //     color = "black"
      // }
      // if(mode === "light"){
      //     color = "white";
      // }
      // console.log(color);

      // let  bhupi = 20;
      // if(bhupi>=18){
      //     console.log("vote");
      // }else {
      //     console.log("note vote ")
      // }

      // let num  = 23;
      // if (num % 2 === 0 ){
      //     console.log("even")
      // }else{
      //     console.log("odd")
      // }

      // let mode = "fvd"

      // let color;
      //  if(mode === "dark"){
      //     color = "black";
      //  }else if(mode === "blue"){
      //     color = "blue";
      //  }else if(mode === "pink"){
      //     color = "pink"
      //  }else{
      //     color = "white"
      //  }

      //  console.log(color);

      // condition statement end here

      //  ternery operater start here

      // let age = 17;
      // let results = age > 17 ? "adult" : "not adult";
      // console.log(results);

      //  ternery operater end here

      // operator and conditional statement end here

      // prompt('what your name')

      // let num = prompt("enter a number");

      // if(num % 3 === 0){
      //     console.log(num, "is a multipale of 3");
      // }else{
      //     console.log(num, "is not a multipale of 3");
      // }

      //let score = prompt("enter your score (0-100):");

      let score = 60;
      let grade;

      if(score >=90 && score <=100){
          grade = "A";
      }else if(score >= 70 && score <=89){
          grade ="B";
      }else if(score >= 60 && score <=69){
          grade ="C";
      }else if(score >=50 && score <=59){
          grade = "D";
      } else if(score >=0 && score <=49){
          grade ="F";
      };

      console.log( "according to your  score", grade);

      // loop in js start here

      // for loop start

      for(let count = 1; count <= 145; count++) {
          console.log("bhupender singh");
      }
      console.log("loop has ended");

      let sum23 = 0;
      for(let ifor=1; ifor<=12; ifor++){
          sum23 = sum23 + ifor;
      }
      console.log("sum = ", sum23);

      // for(var ifor2 = 1; ifor2 <= 10; ifor2++) {
      //     console.log("i =", ifor2);
      // }
      // console.log(ifor2);

      //for loop end

      //while loop start

      let il = 1;
       while(il<=10){
          console.log("i=", il);
          il++;
       }

      //while loop end

      //  do while loop start here

      let i = 10;
      do {
          console.log("i=", i);
          i++;
      }while(i <=5);

      // do while loop end here

      // for of loop start

      let strforof = "bhupender";
      let size = 0;
      for(let g of strforof){
          console.log("i=", g);
          size++;
      }
      console.log("string size = ", size);

      //for of loop end

      //for in loop start

      let student = {
        name: "Bhupender Singh",
        age: 22,
        cgpa: 7.5,
        isPass: true,
      };
      for (let key in student) {
        console.log("key", key, "value", student[key]);
      }

      //for in loop end

      //prectice

      for( let count = 0 ; count <=10; count++){
          if(count%2 !== 0){ //odd number
              console.log('number',count)
          }
      }

      // let gameNumber = 25 ;
      // let userNum = prompt("guess the game number : ");

      // while(userNum != gameNumber){
      //     userNum = prompt("you enterde wrong , number. guess the game number");
      // }
      // console.log("congratualtions you entered the right number ");

      //prectice end

      // loop in js endt here

      // string in js start here

      let strst = "bhupender singh"
      console.log(strst [10]);
        let obj = {
          item: "pen",
          price: 10,
        };

        // let output = `the cost of ${obj.item} is ${obj.price} rupees`;
        // console.log(output);

      //   console.log("the cost of", obj.item, "is ", obj.price, "rupees");

        let specialstring = `this is  a tamplate literal ${5 + 20 + 10}`;
        console.log(specialstring);

      //   console.log("Bhupender\nsingh");
        // console.log("Bhupender\tsingh");

        let strig = "bhupender\tSingh\thakur";
        console.log(strig.length);

      //   let str = "Bhupender Singh";
      //   str = str.toUpperCase();
      //   console.log(str);

        let strloup = "Bhupender Singh";
        strloup = strloup.toUpperCase();
        console.log(strloup);

      let strspc = "  Bhupender   Singh  js   ";  //start and end space remove
      console.log(strspc.trim());

      let strnu = "123456789"; //  kha see start karna hai hai kha tak chaeya contant
      console.log(strnu.slice(1, 7));

      let str1 = "Bhupender";
      let str2 = "Dimpal";
      let strinthree = "seema";
      // let res = str2.concat(str1); //ya string melana ka kam karta hai ak saat
      let res = str2 + str1 + strinthree; // ak he kam karegi
      console.log(res);

      let str5 = "hello "
      console.log(str5.replace("he", "Bhupender singh sipra")); // value ko change karna ke leya is string method ka use keya jata hai


      let str = "ILove_Javascript";
      console.log(str.charAt(1)); // text ko find karna ke leya is string method ka use keya jata hai  ke kon kha par hai contant

      // prectice of  string method

      // let fullName = prompt("Please Enter your full Name widtout space ");
      // let username = "@" + fullName + fullName.length;
      // console.log(username);

      // string in js end here

      //arrays in js start here

      // create array in start here

      let bhup = [50, 30, 88, 94, 50, 46, 89, 84, 89, 12]; //is tarah array ko create karte hai  js me
      console.log(bhup);

       let array = ["bhupender", "Dimpal", "thakur", "seema", "radtha", "babli"];//is tarah array ko create karte hai js me
       console.log(array);

      // create array in end here

      // looping over an array  method start here
      let namesin = [
        "bhupender",
        "Dimpal",
        "thakur",
        "seema",
        "radtha",
        "babli",
      ];

      for (let inx = 0; inx < namesin.length; inx++) {
        console.log(namesin[inx]);
      }

      // looping over an array  method end here

      // prectice in js start here

      // let marks = [85, 25, 30, 50, 80, 45, 90];
      // let sum = 0;
      // for (let val of marks) {
      //  sum = sum + val;
      // }
      // let avg = sum /marks.length;
      // console.log(`avg marks of the class = ${avg}`);

      // offer ka leya js use  start here

      // let items = [250, 645, 300, 900];
      // let idx = 0;
      // for (let val of items) {
      //   console.log(`value at index ${idx} = ${val}`);
      //   let offer = val / 10;
      //   items[idx] = items[idx] - offer;
      //   console.log(`value after offer = ${items[idx]}`);
      //   idx++;
      // }

      // offer ka leya js use  end here

      // prectice in js start here

      //push method start here

      // let  veggites = ["potato", "apple", "litchi", "tomato" ,"mango"] // add value in push methods
      // veggites.push("chips", "burger", "panner")
      // console.log(veggites);

      // let veggites = ["potato", "apple", "litchi", "tomato", "mango"]; // last  value  deleted in pop methods
      // console.log(veggites);
      // let deleteditem = veggites.pop();
      // console.log(veggites);
      // console.log("veggites", deleteditem);

      let veggites = ["potato", "apple", "litchi", "tomato", "mango"]; // tostring methods converts array to straing
      let marks =[45, 20, 50, 80, 91, 12]
      console.log(veggites);
      console.log(veggites.toString());

      // let marverl =["thor", "spiderman", "bhupender", "dimpal"]; // concat method  use this multiple items ko ak saat conact kar data hai
      // let dc_heroes =["superman", "batman"];
      // let hero = marverl.concat(dc_heroes);
      // console.log(hero);

      // let marverl = ["thor", "spiderman", "bhupender", "dimpal"]; //unshift method start value add
      // let val = marverl.unshift("antman");

      let marverl = ["thor", "spiderman", "bhupender", "dimpal"]; //shift method start value deleted
      let val = marverl.shift();
      console.log(marverl);

      // let marverl = ["thor", "spiderman", "bhupender", "dimpal", "seema", "radtha"]; // slice method see item jaha see aapki show karbana hai usko show karva sakta hai slice method see
      // console.log(marverl);
      // console.log(marverl.slice(1, 5,));

      let arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]; // splice method  add , remove and replace karta hai hamara array ya items ko
      arr.splice(2, 1, 50, 30, 52, 51,);
      console.log(arr);

      //arrays in js end here

      function myfunction() {
        console.log("welcome to bhupender Singh");
        console.log("we are learning js");
      }
      myfunction();

      function ineerfunction(msg) {
        //parameter -> input
        console.log(msg);
      }
      ineerfunction("I Love Js"); //argument

      //function -> numbers, sum

      function sum(g, o) {
        s = g + o;
        console.log("before return");
        return s;
      }
      // let val = sum(3, 50);
      // console.log(val);

      //sum function start here

      function sum1(x, y) {
        return x + y;
      }
      console.log(sum1);

      const arrosum = (x, y) => {
        console.log(x + y);
      };
      console.log(arrosum);

      //sum function end here

      //let's practice start here

      function countVowels(str5) {
        //Vowels number in javascript
        let count = 0;
        for (let char of str5.toUpperCase
        ()) {
          if (
            char === "a" ||
            char === "e" ||
            char === "i" ||
            char === "o" ||
            char === "u"
          ) {
            count++;
          }
        }
        return count;
      }

      //let's practice end here

      //forEach Loop in arrays  start here

      let arra = [5, 1, 6, 2, 7, 3, 4, 8, 9, 10];
      arra.forEach(function printval(val) {
        console.log(val);
      });

      // let arra2 =[1, 2, 3, 4, 5, 6, 7, 8, 9,];
      let arra2 = ["bhupender", "Dimpal", "Chander"];
      arra2.forEach((val2, idx, arr) => {
        console.log(val2.toUpperCase(), idx, arr);
      });

      //forEach Loop in arrays  start here

      //let's practice start here here

      let numberp = [8, 6, 5, 2, 3, 4, 7, 1];
      numberp.forEach((numb) => {
        console.log(numb * numb); //
      });

      //let's practice end here here

      //map method start here

      let mapnumber = [1, 2, 5, 8, 5, 7, 3];
      let newarrn = mapnumber.map((val4) => {
        return val4 * 10;
      });
      console.log(newarrn);

      //map method end here

      //filter method in js start here

      let filtermth = [1, 2, 3, 4, 5, 6, 7, 8, 9];
      let newfilter = filtermth.filter((val0) => {
        // return val0 % 2 !== 0;
        return val0 > 2;
      });
      console.log(newfilter);

      //filter method in js end here

      // reduce method in js  start here

      let arrb = [1, 2, 3, 4, 5];
      const output = arrb.reduce((res, curr) => {
        return res + curr;
      });
      console.log(output); //15

      let arrlarg = [1, 2, 1, 4, 501];
      const outputlarg = arrlarg.reduce((prev, curr) => {
        return prev > curr ? prev : curr;
      });
      console.log(outputlarg); //15

      // reduce method in js  end here

      //let's practice start here here

      let marks2 = [64, 91, 97, 50, 30, 95, 86];
      let msrksfilmethod = marks2.filter((valm2) => {
        return valm2 > 90;
      });
      console.log(msrksfilmethod);

      // let n = prompt("enter a number:");
      // let arrprom = [];

      // for (let i = 1; i <= n; i++) {
      //   arrprom[i - 1] = i;
      // }
      // console.log(arrprom);

      // let sumarr = arrprom.reduce((res2, curr2) => {
      //   return res2 + curr2;
      // });
      // console.log(sumarr);

      // let factorial = arrprom.reduce((res2, curr2) => {
      //   return res2 * curr2;
      // });
      // console.log(factorial);

      //let's practice end here here

      // javascript Dom start here

      let leading = document.getElementById("heading2");
      console.log(leading);

      let elements = document.querySelectorAll("p");
      console.dir(elements);

      // javascript Dom end here

      // let's practice start here

      let h3 = document.querySelector("h3"); // html text add karna ke leya use keya jata hai innertext ka
      console.dir(h3.innerText);
      h3.innerText = h3.innerText + " Frome  Bhupender Singh";

      let dives = document.querySelectorAll(".box");
      dives[0].innerText = "new text add in innertext 1";
      dives[1].innerText = "new text add in innertext 2";
      dives[2].innerText = "new text add in innertext 3";

      // let's practice end here

      let h4 = document.querySelector("h4"); // attribute ke value ko  dhakh sakta hai
      console.log(h4);
      let id = h4.getAttribute("id");
      console.log(id);

      let para = document.querySelector("h5"); // class change in js
      console.log(para.setAttribute("class", "new_class"));

      let bhupithakur = document.querySelector("span"); // use js style in html
      bhupithakur.style.fontSize = "50px";
      bhupithakur.style.backgroundColor = "green";
      bhupithakur.style.color = "white";
      bhupithakur.style.padding = "20px";
      bhupithakur.style.borderRadius = "10px";

      let newbtn = document.createElement("button"); // append , prepend, after, before use in js property
      newbtn.innerText = "Click Me"; // add button in html use js
      console.log(newbtn);

      let strong = document.querySelector("strong");
      strong.append(newbtn); // only change apend prepend and after before

      let newheading = document.createElement("h5");
      newheading.innerHTML = "<h6>Hi Bhupender singh </h6>"; // add text in html use only js
      document.querySelector("body").prepend(newheading);

      let parabhu = document.querySelector("p")  //removes the heading & paragraph 
      parabhu.remove();

      // newheading.remove();  //removes the heading & paragraph


      // js event start here
        let btnonclick = document.querySelector("#btnonclick")

        btnonclick.ondblclick =() =>{
            console.log("btnonclick was clicked");
            let a = 25;
            a++;
            console.log(a);//26
        }

          let mousee = document.querySelector("#mouse_e");
          mousee.onmouseover = () =>{
              console.log("your are in side Dive")
          }

        // btnobevent.onclick =(e) =>{
        //     console.log(e)
        //     console.log(e.type)
        //     console.log(e.target)
        //     console.log(e.clientX, e.clientY)
        // }

         btnobevent.addEventListener("click",(evt) => {
          console.log("button was clicked")
          // console.log(evt);
          // console.log(evt.type)
         });

         btnobevent.addEventListener("click",() => {
          console.log("button was clicked2")
         });

         const handler3 = () => {
          console.log("button was clicked3");
         }
         btnobevent.addEventListener("click", handler3);

         btnobevent.addEventListener("click",() => {
          console.log("button was clicked4");
         });

         btnobevent.removeEventListener("click", handler3);
      
         let changemodebtn = document.querySelector("#change_mode");
         let body = document.querySelector("body");
         let crumode ="light";
         change_mode.addEventListener("click", () =>{
          // console.log("you are trying to chang mode in js")
          if(crumode === "light"){
            crumode = "dark";
            document.querySelector("body").style.backgroundColor = "black";
            // document.querySelector("body").style.color = "white";
            body.classList.add("dark");
          }else{
            crumode = "light";
            document.querySelector("body").style.backgroundColor = "white";
            // document.querySelector("body").style.color ="black";
            body.classList.add("light");
          }

          console.log(crumode);
         });
      // js event end here


// tic tac toe game in js start here
          let boxes = document.querySelectorAll(".tic_tac_game");
          let resetbtn = document.querySelector("#reset_btn"); // Updated to use ID selector
          let newgamebtn = document.querySelector("#new_gamebtn");
          let msgcontainer = document.querySelector(".msg-container");
          let msg = document.querySelector("#msg");
          let turn0 = true;
          
          const winPatterns = [
            [0, 1, 2],
            [0, 3, 6],
            [0, 4, 8],
            [1, 4, 7],
            [2, 5, 8],
            [2, 4, 6],
            [3, 4, 5],
            [6, 7, 8],
          ];
          // Add event listeners to each box
          boxes.forEach((box, index) => {
            box.addEventListener("click", () => {
              if (!box.innerText.trim()) { // Ensure box is empty
                box.innerText = turn0 ? "0" : "X";
                turn0 = !turn0; // Toggle turn
                box.disabled = true; // Disable clicked box
                checkwinner();
              }
            });
          });
          // Disable all boxes
          const disablebtn = () => {
            boxes.forEach((box) => (box.disabled = true));
          };
          // Enable all boxes and reset text
          const enablebtnBoxes = () => {
            boxes.forEach((box) => {
              box.disabled = false;
              box.innerText = "";
            });
          };
          // Show winner message
          const showwinner = (winner) => {
            msg.innerText = `Congratulations, the winner is ${winner}!`;
            msgcontainer.classList.remove("hide");
            disablebtn();
          };
          // Reset the game
          const resetGame = () => {
            turn0 = true;
            enablebtnBoxes();
            msg.innerText = ""; // Clear the winner message text
          };
          // Check for a winner
          const checkwinner = () => {
            for (let pattern of winPatterns) {
              let pos1val = boxes[pattern[0]].innerText.trim();
              let pos2val = boxes[pattern[1]].innerText.trim();
              let pos3val = boxes[pattern[2]].innerText.trim();
              
              if (pos1val && pos1val === pos2val && pos2val === pos3val) {
                console.log("Winner:", pos1val);
                showwinner(pos1val);
                return;
              }
            }
          };
          // Add event listeners to buttons
          newgamebtn.addEventListener("click", resetGame);
          resetbtn.addEventListener("click", resetGame); // Using ID selector for reset button
// tic tac toe game in js end here

 // class and object in javascript start here

    const student12 = {
      fullName :"Bhupender Singh",
      marks:64.5,
      printmarks: function(){
        console.log("marks = ",marks);
      },
    };

    const employee ={
      calcTex(){
        console.log("tex rate is 10%")
      }
    }

    const karnarjun = {
      salary: 50000,
    };

    const karnarjun2 = {
      salary: 500,
    };

    const karnarjun3 = {
      salary: 5040,
    };

    const karnarjun4 = {
      salary: 8000,
    };

    karnarjun.__proto__ = employee;
    karnarjun2.__proto__ = employee;
    karnarjun3.__proto__ = employee;
    karnarjun4.__proto__ = employee;

    class ToyotaCar{
      constructor(brand, mileage){
        console.log("create new object ion java script")
        this.brand = brand;
        this.mileage = mileage;
      }

      start(){
        console.log("start");
      }
      stop(){
        console.log("stop");
      }
      setBrand(brand){
        this.brandName = brand;
      }
    }
    let fortuner = new ToyotaCar("fortuner", 10);
    console.log(fortuner);
    fortuner.setBrand("fortuner");


    // inheritance in js start here

    class parent{
      hello(){
        console.log("hello");
      }
    }
    class child extends parent{
    }
    let objin = new child();


    class person  {
      eat(){
        console.log("eat")
      }
      sleep(){
        console.log("sleep")
      }
    }
    class Engineer extends parent{
      work(){
        console.log("solve provlems, build something");
      }
    }
    let beer =  new Engineer();


    class person2  {  //use this class in js super class 
     constructor(name){
      // console.log("enter parent constructor");
      this.species = "home species";
      this.name = name;
     }
      sleep12(){
        console.log("sleep");
      }
    }
    class Engineer2 extends person2{
     constructor(name) {
      // console.log("enter child constructor");
      super(name);  //to invoke parent class constructor
      // this.branch = branch;
      // console.log("exit child constructor")
     }
     work(){
      super.sleep12();  // super is very importent property in javascript
      console.log("solve provlems, build something Bhupender Singh");
    }
    }
    let engiobj =  new Engineer2("Bhupender Singh");

     // inheritance in js end here




    let DATA = "secret information";
    class user {
      constructor(name, email){
        this.name = name;
        this.email = email;
      }
      viewData(){
        console.log("data =", DATA)
      }
    }
    class admin extends user {
      constructor(name, email){
        super(name, email);
      }

      ediData() {
        DATA = "some new value";
      }
    }
    let studentcoll1 = new user("Bhupender","abc@gmail.com");
    let studentcoll2 = new user("seema thakur", "seemakimalch@1234@gmail.com");
    let techer1 = new user("Dean", "dean@college.com")
    let admin1 = new admin("admin", "admin@college.com");



    // Error Handling in js start here
    let a = 5;
    let g =10;
    console.log("a =", a);
    console.log("g =", g);
    try{
      console.log("a+g =",a +dvvdv);
    } catch(err){
        console.log(err);
    }
    console.log("a+g =",a + g);
    console.log("a+g =",a + g);
    console.log("a+g =",a + g);
    console.log("a+g =",a + g);

  // Error Handling in js start here

  //class and object in javascript end here 

// rock paper scisors game start here 

let userScore = 0;
let compScore = 0;
const choices = document.querySelectorAll(".choice");
const userScorepara = document.querySelector("#user_score");
const computerscore = document.querySelector("#computer_score");
const genCompChoice = () =>{
  const option = ["rock", "paper", "scissors"];
  const randIdx = Math.floor(Math.random()*3);
  return option[randIdx];
};
const drowGame = () =>{
  // console.log("Game was drow");
  msgplay.innerText = "Game was Drow. play again";
  msgplay.style.backgroundColor = "#081b31";
}
const showwinner51 =(userWin, userchoice, compChoice) =>{
  if(userWin){
    userScore++;
    userScorepara.innerText = userScore;
    // console.log("you win!");
    msgplay.innerText = `you win! your ${userchoice} beats ${compChoice} `;
    msgplay.style.backgroundColor = "green";
  }else{
    compScore++;
    computerscore.innerText = compScore;
    // console.log("you loss");
    msgplay.innerText = "you loss";
    msgplay.style.backgroundColor = "red";
    msgplay.innerText = `you win! ${compChoice} beats your ${userchoice} `;
  }
}
const playGame = (userchoice) =>{
    // console.log("user chouce = ", userchoice);
  // gentate computer choice
  const compChoice = genCompChoice();
  // console.log("comp choice = ", compChoice);
  if(userchoice === compChoice){
    drowGame();
  }else{
    let userWin = true;
    if(userchoice === "rock"){
      // scissors , paper
     userWin = compChoice === "paper" ? false : true;
    }else if(userchoice === "paper"){
      // rock , scissors
      userWin = compChoice === "scisors" ? false : true;
    }else{
      // rock , paper 
      userWin = compChoice === "rock" ? false: true;
    }
     showwinner51(userWin, userchoice, compChoice );
  }
}
choices.forEach((choice) =>{
  // console.log(choice);
  choice.addEventListener("click",() =>{
    const userchoice = choice.getAttribute("id");
    // console.log("choice Was clicked", userchoice);
    playGame(userchoice);
  });
});
// rock paper scisors game end here  



// console.log("bhupender");
// console.log("bhupender2");
// setTimeout(() => {
//   console.log("hello");
// }, 10000);
// console.log("bhupender3");
// console.log("bhupender4");


// function sun(a, b){
//   console.log(a + b);
// }
// function caluculator(a, b, sumCallback){
//   sumCallback(a, b);
// }
// caluculator(1, 2, (a, b) =>{
//   console.log(a +b);
// });


// const hello2 = ()=>{
//   console.log("hello");
// }
// setTimeout(hello2, 3000);



// nesting
let agenest = 19;
if(agenest>=18){
  if(agenest>60){
    console.log("senior");
  }else{
    console.log("middle")
  }
}else{
  console.log("child")
}


for(let i=0; i<5; i++){
  let strnest = "";
  for(let j=0; j<5; j++){
    strnest =strnest +j;
  }
  console.log(i, strnest);
}


// function getData(dataId, getNexData,){
//   setTimeout(() => {
//     console.log("data", dataId);
//     if(getNexData){
//       getNexData();
//       // getthreddata();
//     }
//   }, 2000);
//   // console.log("data", dadaId);
// };

// callback Hell

// getData(1, ()=>{
//   console.log("getting Data2 .....");
//   getData(2, ()=>{
//     console.log("getting Data3 .....");
//     getData(3);
//   });
// });


//promise  in javascript start here

// let getpromise = new Promise((resolve, reject) =>{
//   console.log("I an promise ");
//   resolve("success");
//   reject ("some arror ");
// });

// const getPromise = () =>{
//   return new Promise ((resolve, reject) =>{
//     console.log("I an a promise");
//    resolve("success");
//     // reject("network error");
//   });
// };
// let promise = getPromise();
// promise.then((res) =>{
//   console.log("promise fulfill", res);
// });
// promise.catch((err) =>{
//   console.log("rejected", err);
// });



// function getData(dataId, getNexData,){
//  return new Promise((resolve, reject) =>{
//   setTimeout(() => {
//     console.log("data", dataId);
//     resolve("success");
//     if(getNexData){
//       getNexData();
//     }
//   }, 3000);
//  });
// };


// p1 = getData(1);
// p1.then((res) =>{
//   console.log("Bhupender Singh", res);
//   getData(2).then(() =>{
//   console.log(res);
//   });
// });




// console.log("getting data1 .....")
// getData(1)
// .then((res) =>{
//   console.log("getting data2 .....")
//   return getData(2);
// })
// .then((res) =>{
//   console.log("getting data3 .....")
//   return getData(3);
// })
// .then((res) =>{
//   console.log("getting data4 .....")
//   console.log(res);
// });


//promise in java script start here



// promise chain in js start here



// function asyncfunc(){
//   // function asyncfunc(): void

//   return new Promise((resolve, reject )=>{
//     setTimeout(() =>{
//      console.log("Same data1");
//      resolve("success");
//     },5000)
//   });
// }
// function asyncfunc2(){
//   // function asyncfunc(): void

//   return new Promise((resolve, reject )=>{
//     setTimeout(() =>{
//      console.log("Same data2");
//      resolve("success");
//     },5000)
//   });
// }

// console.log("feching data1");
// let pl = asyncfunc();
// pl.then((res) =>{
// console.log(res);
// console.log('fetching data2....');
// let pl2 = asyncfunc2();
// pl2.then((res) =>{
// console.log(res)
// });
// });



// console.log("feching data2");
// let pl2 = asyncfunc2();
// pl2.then((res) =>{
// console.log(res);
// });

// promise chain in js end here





// async await in js start here

// async function getweatherData(){
//  await api(1);
//  await api(2);
//  await api(3);
//  await api(4);
// };


// function api(){
//   return new Promise((resolve, reject) =>{
//     setTimeout(() =>{
//       console.log("weather data");
//       resolve(200);
//     }, 2000);
//   });
// }



// function getData(dataId, getNexData,){
//   return new Promise((resolve, reject) =>{
//    setTimeout(() => {
//      console.log("data", dataId);
//      resolve("success");
//    }, 3000);
//   });
//  }; 
//  // Async-await 
// async function  getAllData(){
//   console.log("getting Data1 .....")
//   await getData(1);
//   console.log("getting Data2 .....")
//   await getData(2);
//   console.log("getting Data3 .....")
//   await getData(3);
// }


// async await in js end here

// IIFE function stsrt here

// (async function (){ //auto natic code execute ho jayaga bena function name ke or iife ko 1 bar he use kar sakta hai 
//   console.log("getting Data1 .....")
//   await getData(1);
//   console.log("getting Data2 .....")
//   await getData(2);
//   console.log("getting Data3 .....")
//   await getData(3);
// })();


// IIFE function end here




// fetch API  start here

const URL = "https://cat-fact.herokuapp.com/facts";

const factpr = document.querySelector("#factspara");
const fctbtn = document.querySelector("#factsbtn");

  // let  promise = fetch(URL);
  // console.log(promise);


  const getFacts = async () =>{   // API call  async await batter
    console.log("getting Data ........");
    let responsefact = await fetch(URL);
    console.log(responsefact); // JSON format
    let datafetch  = await responsefact.json();
    factpr.innerText = datafetch[1].text;
  };
  getFacts();
  fctbtn.addEventListener("click", getFacts);


  // function getFacts (){ 
  //   fetch(URL).then ((responsefact) =>{
  //     return responsefact.json();
  //   }).then((data) =>{
  //     console.log(data);
  //     factpr.innerText = data[1].text;
  //   });
  // }
  // getFacts();
  // fctbtn.addEventListener("click", getFacts);

// fetch API  end here



const BASE_URL = "https://2024-03-06.currency-api.pages.dev/v1/currencies";
const dropdowns = document.querySelectorAll(".select-con select");

const btnapi =document.querySelector("form button");
const fromcrr = document.querySelector(".from select");
const tocurr = document.querySelector(".to select");
const backmsg = document.querySelector(".backmsg");


const countryList = {
  AED: "AE",
  AFN: "AF",
  XCD: "AG",
  ALL: "AL",
  AMD: "AM",
  ANG: "AN",
  AOA: "AO",
  AQD: "AQ",
  ARS: "AR",
  AUD: "AU",
  AZN: "AZ",
  BAM: "BA",
  BBD: "BB",
  BDT: "BD",
  XOF: "BE",
  BGN: "BG",
  BHD: "BH",
  BIF: "BI",
  BMD: "BM",
  BND: "BN",
  BOB: "BO",
  BRL: "BR",
  BSD: "BS",
  NOK: "BV",
  BWP: "BW",
  BYR: "BY",
  BZD: "BZ",
  CAD: "CA",
  CDF: "CD",
  XAF: "CF",
  CHF: "CH",
  CLP: "CL",
  CNY: "CN",
  COP: "CO",
  CRC: "CR",
  CUP: "CU",
  CVE: "CV",
  CYP: "CY",
  CZK: "CZ",
  DJF: "DJ",
  DKK: "DK",
  DOP: "DO",
  DZD: "DZ",
  ECS: "EC",
  EEK: "EE",
  EGP: "EG",
  ETB: "ET",
  EUR: "FR",
  FJD: "FJ",
  FKP: "FK",
  GBP: "GB",
  GEL: "GE",
  GGP: "GG",
  GHS: "GH",
  GIP: "GI",
  GMD: "GM",
  GNF: "GN",
  GTQ: "GT",
  GYD: "GY",
  HKD: "HK",
  HNL: "HN",
  HRK: "HR",
  HTG: "HT",
  HUF: "HU",
  IDR: "ID",
  ILS: "IL",
  INR: "IN",
  IQD: "IQ",
  IRR: "IR",
  ISK: "IS",
  JMD: "JM",
  JOD: "JO",
  JPY: "JP",
  KES: "KE",
  KGS: "KG",
  KHR: "KH",
  KMF: "KM",
  KPW: "KP",
  KRW: "KR",
  KWD: "KW",
  KYD: "KY",
  KZT: "KZ",
  LAK: "LA",
  LBP: "LB",
  LKR: "LK",
  LRD: "LR",
  LSL: "LS",
  LTL: "LT",
  LVL: "LV",
  LYD: "LY",
  MAD: "MA",
  MDL: "MD",
  MGA: "MG",
  MKD: "MK",
  MMK: "MM",
  MNT: "MN",
  MOP: "MO",
  MRO: "MR",
  MTL: "MT",
  MUR: "MU",
  MVR: "MV",
  MWK: "MW",
  MXN: "MX",
  MYR: "MY",
  MZN: "MZ",
  NAD: "NA",
  XPF: "NC",
  NGN: "NG",
  NIO: "NI",
  NPR: "NP",
  NZD: "NZ",
  OMR: "OM",
  PAB: "PA",
  PEN: "PE",
  PGK: "PG",
  PHP: "PH",
  PKR: "PK",
  PLN: "PL",
  PYG: "PY",
  QAR: "QA",
  RON: "RO",
  RSD: "RS",
  RUB: "RU",
  RWF: "RW",
  SAR: "SA",
  SBD: "SB",
  SCR: "SC",
  SDG: "SD",
  SEK: "SE",
  SGD: "SG",
  SKK: "SK",
  SLL: "SL",
  SOS: "SO",
  SRD: "SR",
  STD: "ST",
  SVC: "SV",
  SYP: "SY",
  SZL: "SZ",
  THB: "TH",
  TJS: "TJ",
  TMT: "TM",
  TND: "TN",
  TOP: "TO",
  TRY: "TR",
  TTD: "TT",
  TWD: "TW",
  TZS: "TZ",
  UAH: "UA",
  UGX: "UG",
  USD: "US",
  UYU: "UY",
  UZS: "UZ",
  VEF: "VE",
  VND: "VN",
  VUV: "VU",
  YER: "YE",
  ZAR: "ZA",
  ZMK: "ZM",
  ZWD: "ZW",
};


 
for (let select of dropdowns){
  for (currcode in countryList){
    let newOption = document.createElement("option");
    newOption.innerText = currcode;
    newOption.value = currcode;
    if(select.name === "from" && currcode === "USD"){
      newOption.selected = "selected";
    }else if(select.name === "to" && currcode === "INR"){
      newOption.selected = "selected";
    }
    select.append(newOption);
  }
  select.addEventListener("change", (evt) =>{
    updateFlag(evt.target);
  });
}

const updateFlag = (element) =>{
  let currcode = element.value;
  // console.log(currcode);
  let countrycode = countryList[currcode]; 
  let newSrc =`https://flagsapi.com/${countrycode}/flat/64.png`;
  let img = element.parentElement.querySelector("img");
  img.src = newSrc;
}



btnapi.addEventListener("click", async (evt) =>{
  evt.preventDefault();
  let amount = document.querySelector(".amount input");
  let amtVal = amount.value;
  if(amtVal === "" || amtVal < 1){
    amtVal = 1;
  amount.value = "1";
  }
  // console.log(amtVal);

  const URL = `${BASE_URL}/${fromcrr.toLowerCase()}/${tocurr.toLowerCase()}.json`;
    
  
  let responseapi = await fetch(URL);
  let dataapi = await responseapi.json();
  let rate = dataapi[tocurr.value.toLowerCase()];
 

  let finalamount = amtVal * rate;

  backmsg.innerText = `${amtVal} ${fromcrr.value} = ${finalamount} ${tocurr.value}`

});